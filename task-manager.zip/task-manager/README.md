# React Task Manager (Part 1)

## Run
```bash
npm install
npm run dev
```

## Structure
```
App               (owns tasks state: add / toggle / delete)
├── Header        (title + remaining count)
├── TaskForm      (controlled input + validation)
└── TaskList      (maps tasks array)
    └── TaskItem  (checkbox toggle + delete button)
```
