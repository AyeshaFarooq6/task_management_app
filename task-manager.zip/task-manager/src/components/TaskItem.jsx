export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <li className={`task-item ${task.completed ? 'is-complete' : ''}`}>
      <label>
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => onToggle(task.id)}
        />
        <span>{task.text}</span>
      </label>
      <button
        className="delete"
        onClick={() => onDelete(task.id)}
        aria-label={`Delete task: ${task.text}`}
      >
        Delete
      </button>
    </li>
  );
}
