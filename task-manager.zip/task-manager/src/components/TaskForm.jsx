import { useState } from 'react';

export default function TaskForm({ onAdd }) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = text.trim();

    // Validation: block empty / whitespace-only tasks
    if (!trimmed) {
      setError('Please enter a task before adding.');
      return;
    }

    onAdd(trimmed);
    setText('');
    setError('');
  };

  return (
    <form className="task-form" onSubmit={handleSubmit} noValidate>
      <div className="task-form__row">
        <input
          type="text"
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            if (error) setError('');
          }}
          placeholder="What needs doing?"
          aria-label="New task"
          aria-invalid={!!error}
        />
        <button type="submit">Add task</button>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
    </form>
  );
}
