export default function Header({ total, remaining }) {
  return (
    <header className="header">
      <h1>Task Manager</h1>
      <p>
        {total === 0
          ? 'Nothing on your list yet.'
          : `${remaining} of ${total} tasks left to do`}
      </p>
    </header>
  );
}
